let Navwrapper = document.querySelector('.nav__wrapper')
let hamburger = document.querySelector('.hamburger')
hamburger.addEventListener('click',()=>{
    Navwrapper.classList.toggle('display')
})